# Sign language Project > 2024-04-01 3:14pm
https://universe.roboflow.com/signlang-suaqi/sign-language-project-vrh43

Provided by a Roboflow user
License: CC BY 4.0

